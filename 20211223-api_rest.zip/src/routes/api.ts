import { Router } from "express";

import * as ScheduleController from "../controllers/scheduleController";
import * as NewsletterController from "../controllers/newsletterController";

const router = Router();


router.post('/newsletter', NewsletterController.createNewsletter)
router.get('/newsletter', NewsletterController.getNewsletter)

router.post('/schedule', ScheduleController.createSchedule)
router.get('/schedule', ScheduleController.getSchedule)

export default router;